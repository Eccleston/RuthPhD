%% Example of generating string

base = fileread('sweep_data.lbs');%('lbs_base.lbs');
datadir = '../Data/';

dat1 = dlmread([datadir 'AllData_150520_ASN_SSL.txt'],',',1,1);
locs = 3:66;
SSL_cyt_none = reshape(dat1(locs,1),8,8);
SSL_surf_none = reshape(dat1(locs,2),8,8);
SSL_cyt_ifn1 = reshape(dat1(locs,3),8,8);
SSL_surf_ifn1 = reshape(dat1(locs,4),8,8);
SSL_cyt_ifn2 = reshape(dat1(locs,5),8,8);
SSL_surf_ifn2 = reshape(dat1(locs,6),8,8);
ASN_cyt_none = reshape(dat1(locs,7),8,8);
ASN_cyt_ifn1 = reshape(dat1(locs,8),8,8);
ASN_cyt_ifn2 = reshape(dat1(locs,9),8,8);

A = [SSL_cyt_none(:,1) ASN_cyt_none(:,1);
     SSL_cyt_none(:,2) ASN_cyt_none(:,2);
     SSL_cyt_none(:,3) ASN_cyt_none(:,3);
     SSL_cyt_none(:,4) ASN_cyt_none(:,4);
     SSL_cyt_none(:,5) ASN_cyt_none(:,5);
     SSL_cyt_none(:,6) ASN_cyt_none(:,6);
     SSL_cyt_none(:,7) ASN_cyt_none(:,7);
     SSL_cyt_none(:,8) ASN_cyt_none(:,8);];
%A = [1.0 1.0;
 % 2.0 1.0;
  %3.0 1.0;
  %4.0 1.0;
  %5.0 1.0;
  %1.0 2.0;
  %2.0 2.0;
  %3.0 2.0;
  %4.0 2.0;
  %5.0 2.0];

str = 'directive sweep mysweep = { (in1,in2) = [';
% Start with first entry
str = sprintf('%s(%1.2f,%1.2f)',str,A(1,1),A(1,2));
% Then add a comma and additional entries in a loop
for i = 2:length(A)
  str = sprintf('%s,(%1.2f,%1.2f)',str,A(i,1),A(i,2));
end
% Add the final delimiter
str = strcat(str,'] }');

fid = fopen('temp.lbs','w');
fprintf(fid,'//Auto-generated sweep\r\n%s\r\n\r\n',str);
fclose(fid);
system('copy /b temp.lbs+sweep_data.lbs combined_new.lbs');
%system('copy /b temp.lbs+lbs_base.lbs combined.lbs');

for k=1:8
    for j=1:8
        str2='SSL_';
eval(sprintf('%s%1.2d_%1.2d=%1.2d',str2,SSL_cyt_none(j,k), ASN_cyt_none(j,k),SSL_surf_none(j,k)));
    end
end
str3='Time';
str3=sprintf('%s \t %s%1.2d_%1.2d',str3,'SSL_',A(1,1),A(1,2));
for i = 2:length(A)
  str3 = sprintf('%s \t %s%1.2d_%1.2d',str3,'SSL_',A(i,1),A(i,2));
end
time=24*3600;
T=zeros(1,1); T=time;
D=horzcat(SSL_surf_none(:,1)',SSL_surf_none(:,2)',SSL_surf_none(:,3)',SSL_surf_none(:,4)',SSL_surf_none(:,5)',SSL_surf_none(:,6)',SSL_surf_none(:,7)',SSL_surf_none(:,8)')
fid3=fopen('test.txt','w');
fprintf(fid3, str3);
fprintf(fid3, '\n');
fprintf(fid3, '%1.2d \t',D);


fclose(fid3);



return