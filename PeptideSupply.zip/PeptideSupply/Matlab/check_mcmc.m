
sf1=0.00264217448420823;
sf2=0.153151974081993;
sf=0.00221045827493072;
gM=150.5;

%% Load data

datadir = '../Data/';

dat1 = dlmread([datadir 'AllData_150520_ASN_SSL.txt'],',',1,1);
locs = 3:66;
SSL_cyt_none = reshape(dat1(locs,1),8,8);
SSL_surf_none = reshape(dat1(locs,2),8,8);
SSL_cyt_ifn1 = reshape(dat1(locs,3),8,8);
SSL_surf_ifn1 = reshape(dat1(locs,4),8,8);
SSL_cyt_ifn2 = reshape(dat1(locs,5),8,8);
SSL_surf_ifn2 = reshape(dat1(locs,6),8,8);
ASN_cyt_none = reshape(dat1(locs,7),8,8);
ASN_cyt_ifn1 = reshape(dat1(locs,8),8,8);
ASN_cyt_ifn2 = reshape(dat1(locs,9),8,8);

% Set u1 to be the measurement of the target peptide off-rate
u1 = log(2)/(728.5746 * 60);
% Set u2 to be the measurement of the competitor peptide off-rate
u2 = log(2)/(337.9968 * 60);

% Set gtarget_none to be the measurement of the target peptide
% (cytoplasm)without IFN
gtarget_none_1=SSL_cyt_none;%
% Set gcomp_none to be the measurement of the competitor peptide
% (cytoplasm) without IFN
gcomp_none_1=ASN_cyt_none;
% Set data_none to be the cell surface measure of the target peptide
% without IFN
data_none_1 = SSL_surf_none;

Ng1=8; Ng2=8;

for i1=1:Ng1
    for i2=1:Ng1
                
        [MeP1_none_1(i1, i2), MeP2_none_1(i1, i2)]=simulateMHC_asn_ssl(sf1*gtarget_none_1(i1, i2), sf2*gcomp_none_1(i1, i2), u1, u2, gM);
        %[MeP1_none_2(i1, i2), MeP2_none_2(i1, i2)]=simulateMHC_asn_ssl(sf1*gtarget_none_2(i1, i2), sf2*gcomp_none_2(i1, i2), u1, u2, gM1);
        %[MeP1_ifn1_1(i1, i2), MeP2_ifn1_1(i1, i2)]=simulateMHC_asn_ssl(sf1*gtarget_ifn1_1(i1, i2), sf2*gcomp_ifn1_1(i1, i2), u1, u2, upreg*gM1);
        %[MeP1_ifn1_2(i1, i2), MeP2_ifn1_2(i1, i2)]=simulateMHC_asn_ssl(sf1*gtarget_ifn1_2(i1, i2), sf2*gcomp_ifn1_2(i1, i2), u1, u2, upreg*gM1);
    end
end


p_MeP1_none_1=[sf 0];%;%p_MeP1_both;
%p_MeP2_none_2=[sf4 0];%p_MeP2_both;
%p_MeP1_ifn1_1=[sf 0];%p_MeP1_both;
%p_MeP2_ifn1_2=[sf4 0];%p_MeP2_both;

%p_MeP1_both
%p_MeP2_both
cmap=hsv(8);
figure(1);
semilogx(gtarget_none_1(:,1),p_MeP1_none_1(1)*MeP1_none_1(:,1)+p_MeP1_none_1(2),gtarget_none_1(:,1),data_none_1(:,1),'o','Color',cmap(1,:),'LineWidth',2,'MarkerSize',10);hold on;
semilogx(gtarget_none_1(:,2),p_MeP1_none_1(1)*MeP1_none_1(:,2)+p_MeP1_none_1(2),gtarget_none_1(:,2),data_none_1(:,2),'o','Color',cmap(2,:),'LineWidth',2,'MarkerSize',10);
semilogx(gtarget_none_1(:,3),p_MeP1_none_1(1)*MeP1_none_1(:,3)+p_MeP1_none_1(2),gtarget_none_1(:,3),data_none_1(:,3),'o','Color',cmap(3,:),'LineWidth',2,'MarkerSize',10);
semilogx(gtarget_none_1(:,4),p_MeP1_none_1(1)*MeP1_none_1(:,4)+p_MeP1_none_1(2),gtarget_none_1(:,4),data_none_1(:,4),'o','Color',cmap(4,:),'LineWidth',2,'MarkerSize',10);
semilogx(gtarget_none_1(:,5),p_MeP1_none_1(1)*MeP1_none_1(:,5)+p_MeP1_none_1(2),gtarget_none_1(:,5),data_none_1(:,5),'o','Color',cmap(5,:),'LineWidth',2,'MarkerSize',10);
semilogx(gtarget_none_1(:,6),p_MeP1_none_1(1)*MeP1_none_1(:,6)+p_MeP1_none_1(2),gtarget_none_1(:,6),data_none_1(:,6),'o','Color',cmap(6,:),'LineWidth',2,'MarkerSize',10);
semilogx(gtarget_none_1(:,7),p_MeP1_none_1(1)*MeP1_none_1(:,7)+p_MeP1_none_1(2),gtarget_none_1(:,7),data_none_1(:,7),'o','Color',cmap(7,:),'LineWidth',2,'MarkerSize',10);
semilogx(gtarget_none_1(:,8),p_MeP1_none_1(1)*MeP1_none_1(:,8)+p_MeP1_none_1(2),gtarget_none_1(:,8),data_none_1(:,8),'o','Color',cmap(8,:),'LineWidth',2,'MarkerSize',10);
xlabel('mCherry MFI','FontSize',16);ylabel('1C3 + GAM-AF647','FontSize',16);
legend({'P2 P9',' ','P10 P17',' ','P18 P25',' ','P26 P33',' ','P34 P40',' ','P42 P39',' ','P50 P57',' ','P58 P65',' '})
%legend({'V-ASN P2',' ','V-ASN P10',' ','V-ASN P18',' ','V-ASN P26',' ','V-ASN P34 ',' ','V-ASN P42',' ','V-ASN P50',' ','V-ASN P58',' '})
set(gca, 'FontSize',16);
hold off